(* simple if *)

if false then read else 1

(* result : int *)
