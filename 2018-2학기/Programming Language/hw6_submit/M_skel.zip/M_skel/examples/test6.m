(* Public testcase 6 : type error *)

if 1 = true then write 1 else write 2

(* Output : type error *)
