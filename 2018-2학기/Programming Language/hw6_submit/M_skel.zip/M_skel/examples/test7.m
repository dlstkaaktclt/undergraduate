(* Public testcase 7 : type error *)

if (1, 2) = (1, 2) then write 1 else write 2

(* Output : type error *)
